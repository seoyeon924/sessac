
import { GoogleGenAI, Type } from "@google/genai";
import { MentorshipProfile, Mission, Proficiency, CareerGoal, Lesson } from "./types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * 멘토 Sarah와의 실무 오리엔테이션 시나리오 생성 (요청 대본 기반 고정 및 고도화)
 */
export const generateMentorDialogueSession = async (
  profile: MentorshipProfile,
  mission: Mission,
  lesson: Lesson,
  phase: 'INTRO' | 'OUTRO',
  nickname: string 
) => {
  const isIntro = phase === 'INTRO';
  
  if (mission.id === '1-1' && isIntro) {
    switch (lesson.id) {
      case '1-1-1': // 1-1. [BI 실무 기초] 대시보드 실무 사례
        return [
          { speaker: "사라 사수", text: `안녕하세요, **${nickname}**님! 오늘부터 저와 함께 데이터 분석의 실무를 배우게 될 거예요. 긴장하지 마세요, 제가 차근차근 도와드릴게요.`, isUserTurn: false },
          { speaker: nickname, text: `네, 사라님! 잘 부탁드립니다. 그런데 대시보드라는 게 실제 업무에서 어떻게 쓰이는지 먼저 보고 싶어요.`, isUserTurn: true },
          { speaker: "사라 사수", text: `역시 **${nickname}**님은 실천파시네요! 대시보드는 도메인마다 활용법이 정말 다양해요. 제가 세 가지 아주 훌륭한 사례를 보여드릴게요.`, isUserTurn: false },
          { speaker: "사라 사수", text: `첫 번째는 게임 로그 대시보드예요. 게임 업계에서는 유저가 얼마나 남느냐가 생명이거든요. 특정 행동을 한 유저들이 그렇지 않은 유저보다 얼마나 더 게임에 잘 남는지 추이를 분석하죠. 매출 흐름도 실시간으로 파악하고요.`, isUserTurn: false },
          { speaker: "사라 사수", text: `이 링크를 한번 보세요: [게임 로그 대시보드 보기](https://public.tableau.com/app/profile/.83057946/viz/12-3_GameLogDashboard_17534330076730/GameDashboard)`, isUserTurn: false },
          { speaker: nickname, text: `우와, 화면이 정말 화려하네요! 여기서 뭘 중점적으로 봐야 하나요?`, isUserTurn: true },
          { speaker: "사라 사수", text: `여기서는 **Day 1 Retention(1일 차 재방문율)**을 보셔야 해요. 특정 행동(예: 튜토리얼 완료)을 한 유저가 그렇지 않은 유저보다 유지율이 높은지 확인하는 게 핵심이죠.`, isUserTurn: false },
          { speaker: "사라 사수", text: `두 번째는 인사팀에서 참고하기 좋은 HR ATTRITION 대시보드예요.`, isUserTurn: false },
          { speaker: "사라 사수", text: `[HR Attrition Dashboard 보기](https://public.tableau.com/app/profile/pradeepkumar.g/viz/HRAttritionDashboardRWFD_16570446563570/viz)`, isUserTurn: false },
          { speaker: nickname, text: `이건 디자인이 정말 깔끔하고 예뻐요!`, isUserTurn: true },
          { speaker: "사라 사수", text: `맞아요. 이 대시보드는 세계적인 시각화 어워드인 'Information is Beautiful' 수상작이에요. 퇴사율 같은 무거운 데이터를 UX적으로 어떻게 직관적으로 표현했는지 공부하기 딱 좋답니다.`, isUserTurn: false },
          { speaker: "사라 사수", text: `마지막으로 마케팅과 영업의 꽃, Sales Funnel 대시보드입니다.`, isUserTurn: false },
          { speaker: "사라 사수", text: `[Sales Funnel Dashboard 보기](https://public.tableau.com/app/profile/.83057946/viz/SalesFunnelDashboard_16570254084520/SalesPipelineDashboard)`, isUserTurn: false },
          { speaker: nickname, text: `오, 이건 외국계 기업에서 많이 쓸 것 같아요.`, isUserTurn: true },
          { speaker: "사라 사수", text: `정확해요! 특히 한국 지사처럼 영업 조직이 메인인 곳에서 매니저들이 "어떤 계약(Deal)에 집중해야 하는가?"를 판단할 때 써요. 단계별 전환율을 보고 병목 지점을 바로 찾아내죠.`, isUserTurn: false },
          { speaker: nickname, text: `사라님, 사례를 보니까 대시보드가 왜 필요한지 확 와닿아요.`, isUserTurn: true },
          { speaker: "사라 사수", text: `다행이에요. 자, 이제 이 사례들을 가슴에 품고, 왜 우리가 엑셀을 넘어 BI를 배워야 하는지 본격적으로 알아볼까요?`, isUserTurn: false }
        ];

      case '1-1-2': // 1-2. BI의 필요성
        return [
          { speaker: "사라 사수", text: `**${nickname}**님, 우리 평소에 엑셀 정말 많이 쓰잖아요? 그런데 왜 굳이 어려운 BI 툴을 또 배워야 할까요?`, isUserTurn: false },
          { speaker: nickname, text: `저도 그게 궁금했어요. 엑셀로도 충분히 그래프를 그릴 수 있잖아요.`, isUserTurn: true },
          { speaker: "사라 사수", text: `실무에서는 **'반복되는 비효율'**과 **'소통의 간극'**이라는 큰 벽이 있어요. 예를 들어, 사업팀에서 "지역별 판매 현황 보고 싶어요"라고 하면 데이터팀은 추출하고 가공하는 데만 며칠이 걸리기도 하죠.`, isUserTurn: false },
          { speaker: nickname, text: `며칠이나요? 너무 오래 걸리네요.`, isUserTurn: true },
          { speaker: "사라 사수", text: `그렇죠. 게다가 기술 용어 차이 때문에 서로 말이 안 통할 때가 많아요. BI는 바로 이 간극을 연결해서 누구나 실시간으로 업데이트되는 데이터를 웹 링크 하나로 공유하게 해준답니다. 단순 리포트가 아니라 '의사결정 엔진'인 셈이죠.`, isUserTurn: false }
        ];

      case '1-1-3': // 1-3. 데이터 시각화란?
        return [
          { speaker: "사라 사수", text: `**${nickname}**님, 혹시 "숫자는 거짓말을 하지 않지만, 진실을 다 말해주지도 않는다"는 말을 들어보셨나요?`, isUserTurn: false },
          { speaker: nickname, text: `숫자가 진실을 말하지 않는다고요? 왜 그런가요?`, isUserTurn: true },
          { speaker: "사라 사수", text: `여기 **'데이터사우르스(Datasaurus)'** 예시가 있어요. 평균이나 분산 같은 통계 수치는 똑같은데, 시각화해보면 공룡 모양이나 하트 모양으로 전혀 다르거든요.`, isUserTurn: false },
          { speaker: nickname, text: `우와, 통계만 믿었다가는 큰일 나겠는데요?`, isUserTurn: true },
          { speaker: "사라 사수", text: `맞아요. 우리 눈의 **'전주의적 속성'**을 활용해 수만 개의 숫자 속에서 '이상치'를 단번에 찾게 돕는 것이 시각화의 힘이에요. 결국 시각화의 본질은 그냥 보여주는 게 아니라 **'설득'**이고 **'소통'**이랍니다.`, isUserTurn: false }
        ];

      case '1-1-4': // 2-1. 분석 목적 세우기
        return [
          { speaker: "사라 사수", text: `이제 본격적으로 시각화를 시작해볼 텐데, **${nickname}**님은 무엇부터 하실 건가요?`, isUserTurn: false },
          { speaker: nickname, text: `음, 일단 데이터를 태블로에 넣고 예쁜 차트를 그려볼 것 같아요!`, isUserTurn: true },
          { speaker: "사라 사수", text: `아차! 그게 바로 초보들이 가장 많이 하는 실수예요. 목적 없이 데이터를 열면 나중에 "이걸 누가 봐야 하지?"라는 질문에 답을 못해요.`, isUserTurn: false },
          { speaker: "사라 사수", text: `그래서 반드시 **5가지 질문(Who, Why, What, How, When)**을 먼저 던져야 합니다. 누구를 위한 대시보드인지, 왜 중요한지, 어떤 액션을 할 건지 정하는 게 차트 그리는 것보다 훨씬 중요해요.`, isUserTurn: false },
          { speaker: nickname, text: `"회원가입자 1만 명"보다 "활성 사용자 비율 30%"가 더 중요하다는 말씀이죠?`, isUserTurn: true },
          { speaker: "사라 사수", text: `완벽해요! 시각화는 기술이 아니라 **'목적을 설계하는 과정'**임을 꼭 기억해 주세요.`, isUserTurn: false }
        ];

      case '1-1-5': // 2-2. Actionable 지표 구조
        return [
          { speaker: "사라 사수", text: `목적을 세웠다면 이제 지표를 층층이 쌓아 올릴 차례예요. 이걸 **지표 계층 구조(Metric Hierarchy)**라고 불러요.`, isUserTurn: false },
          { speaker: nickname, text: `지표를 층층이 쌓는다는 게 어떤 의미인가요?`, isUserTurn: true },
          { speaker: "사라 사수", text: `매출이 떨어졌을 때 "왜?"라는 질문에 바로 답하게 만드는 설계도예요. 성과(Outcome), 영향(Driver), 실행(Actionable) 지표로 나누죠.`, isUserTurn: false },
          { speaker: "사라 사수", text: `결과인 '매출'이 성과라면, 거기에 영향을 주는 '전환율'이 영향 지표고, 우리가 당장 수정 가능한 '버튼 위치나 클릭률'이 실행 지표가 되는 거예요.`, isUserTurn: false },
          { speaker: nickname, text: `아! 버튼 클릭률이 낮아서 매출이 떨어졌다는 논리가 완성되네요?`, isUserTurn: true },
          { speaker: "사라 사수", text: `정답이에요! 이렇게 연결하면 단순히 숫자를 관찰하는 게 아니라 실질적인 개선안을 낼 수 있게 되죠. 이게 바로 **Actionable**한 시각화의 핵심이랍니다.`, isUserTurn: false }
        ];

      case '1-1-6': // 2-3. 차트 유형
        return [
          { speaker: "사라 사수", text: `**${nickname}**님, 실무 대시보드의 80%를 차지하는 차트가 딱 3가지 있는데, 뭔지 아시나요?`, isUserTurn: false },
          { speaker: nickname, text: `음... 막대그래프? 말고는 잘 모르겠어요.`, isUserTurn: true },
          { speaker: "사라 사수", text: `바로 라인, 막대, 도넛 차트예요. 라인은 흐름, 막대는 비교, 도넛은 비중을 보여줄 때 쓰죠. 그리고 대시보드를 배치할 때도 최상단 KPI에서 시작해 아래로 갈수록 상세 분석 데이터(Raw Data)로 이어지는 흐름이 가장 좋아요.`, isUserTurn: false },
          { speaker: nickname, text: `마치 피라미드처럼 위에서 아래로 구체화되는 느낌이네요!`, isUserTurn: true },
          { speaker: "사라 사수", text: `정확해요! 큰 그림에서 시작해 이상 지점을 발견하고, 세부 원인을 찾아 액션까지 이어지게 만드는 것이 좋은 대시보드 구조랍니다.`, isUserTurn: false }
        ];

      case '1-1-7': // 2-4. 디자인 원칙
        return [
          { speaker: "사라 사수", text: `이제 차트를 예쁘고 읽기 좋게 다듬어볼까요? 대원칙은 하나예요. "시그널은 최대화하고, 노이즈는 최소화하라!"`, isUserTurn: false },
          { speaker: nickname, text: `노이즈를 줄인다는 건 어떤 건가요?`, isUserTurn: true },
          { speaker: "사라 사수", text: `불필요한 배경선이나 화려한 3D 효과를 버리는 거예요. 이걸 **'데이터 잉크 비율'**을 높인다고 하죠. 막대그래프 축은 반드시 0부터 시작해야 정확한 비교가 된다는 점, 색상은 강조하고 싶은 요소에만 써야 한다는 점을 절대 잊지 마세요!`, isUserTurn: false },
          { speaker: nickname, text: `꺾은선 그래프도 축을 0부터 시작해야 하나요?`, isUserTurn: true },
          { speaker: "사라 사수", text: `날카로운 질문이에요! 꺾은선은 흐름이 중요하기 때문에 변화를 더 잘 보여주기 위해 축을 적절히 잘라내도 괜찮답니다. 상황에 맞는 유연함이 필요하죠.`, isUserTurn: false }
        ];

      case '1-1-8': // 2-5. 인사이트 도출
        return [
          { speaker: "사라 사수", text: `드디어 마지막 단계네요! 시각화된 데이터에서 어떻게 인사이트를 뽑아낼까요? 딱 3단계만 기억하세요. **평가 → 원인 후보 나열 → 드릴다운**.`, isUserTurn: false },
          { speaker: nickname, text: `첫 번째 '평가'는 어떻게 하나요?`, isUserTurn: true },
          { speaker: "사라 사수", text: `비교 기준을 정하는 거예요. 전년 대비 어떤지, 평균 대비 어떤지 기준이 있어야 '좋다, 나쁘다'를 평가할 수 있죠. 그다음 가설을 세우고 시각화로 검증하는 거예요.`, isUserTurn: false },
          { speaker: "사라 사수", text: `이때 주의할 점은 **심슨의 역설(Simpson's Paradox)**이에요. 전체적으로는 좋아 보여도 그룹별로 쪼개보면 결과가 뒤집힐 수 있거든요. 항상 데이터를 다각도로 쪼개보는 습관이 중요합니다.`, isUserTurn: false },
          { speaker: nickname, text: `사라님 덕분에 챕터 1의 전체 흐름을 완벽히 이해했어요!`, isUserTurn: true },
          { speaker: "사라 사수", text: `정말 고생 많으셨어요, **${nickname}**님! 그럼 이제 가이드북을 보면서 내용을 정리하고, 다음 챕터에서 본격적으로 태블로를 만져볼까요?`, isUserTurn: false }
        ];
    }
  }

  // 기본 AI 대화 생성 로직 (CH 2 이후)
  const prompt = `당신은 시니어 BI 멘토 Sarah입니다. ${nickname}님과 "${lesson.title}"에 대해 대화하세요. JSON 형식으로 5개 이내의 dialogues를 생성하세요.`;
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: { responseMimeType: "application/json" }
  });
  const result = JSON.parse(response.text || '{"dialogues": []}');
  return result.dialogues;
};

export const askMentor = async (message: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Sarah 사수입니다. 질문: ${message}. 실무적인 답변을 해주세요.`,
    });
    return response.text || "잠시 확인이 필요합니다.";
  } catch (error) {
    return "연결 오류가 발생했습니다.";
  }
};

export const generateLearningPath = async (p: any, g: any) => ({ proficiency: p, goal: g, recommendedMissionIds: ['1-1', '2-1'], customPlan: "최단기 실무 마스터 경로" });
