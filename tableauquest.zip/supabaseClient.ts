
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.7';

/**
 * 🛠️ Supabase 연동 정보
 * URL: https://tgnadgsvoerlgcfgpexq.supabase.co
 * Key: sb_publishable_rUKFpnXuxlqBmyrFbgIzNQ_lVpI-wTC
 */

const SUPABASE_URL = 'https://tgnadgsvoerlgcfgpexq.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_rUKFpnXuxlqBmyrFbgIzNQ_lVpI-wTC';

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
